# ap2-mandates

Strict JSON Schemas + TypeScript interfaces for the three AP2 mandate types,
plus a validation module that checks both structure (via [ajv](https://ajv.js.org/),
draft 2020-12) and cross-field/cross-mandate business rules that JSON Schema
can't express on its own (e.g. "line totals sum to the cart total", "payment
amount matches the cart it settles").

## Layout

```
schemas/
  intent-mandate.schema.json    # IntentMandate
  cart-mandate.schema.json      # CartMandate (incl. LineItem in $defs)
  payment-mandate.schema.json   # PaymentMandate
src/
  types/mandates.ts             # TypeScript interfaces mirroring the schemas
  validation/index.ts           # ajv compilation + semantic checks
  index.ts                      # public entry point
```

## Install & build

```bash
npm install
npm run build
```

## Usage

```ts
import {
  validateIntentMandate,
  validateCartMandate,
  validatePaymentMandate,
  validateMandateChain,
} from "ap2-mandates";

const result = validateIntentMandate(someUnknownPayload);
if (!result.valid) {
  console.error(result.errors); // string[]
} else {
  // result.data is typed as IntentMandate
}

// Structural + semantic validation across a whole intent -> cart -> payment chain:
const chain = validateMandateChain(rawIntent, rawCart, rawPayment);
if (!chain.valid) console.error(chain.errors);
```

## What "strict" means here

- Every schema sets `"additionalProperties": false` — unknown fields are rejected.
- `max_paise` / `final_paise` are integers (paise, not rupees) with bounds.
- `expiry_timestamp` / `created_at` are validated as ISO 8601 (`format: date-time`).
- IDs (`intent_id`, `cart_id`, `payment_id`, and the `*_reference` fields) are
  validated as UUIDs.
- `allowed_categories` requires at least one entry, no duplicates, and each
  entry matches a snake_case slug pattern.
- Each `LineItem.locked` field is a `const: true` — a cart line item is never
  representable as "unlocked" by the schema.

## What schema validation can't do (handled at runtime instead)

JSON Schema can't do arithmetic across array items or compare sibling
mandates, so `src/validation/index.ts` adds:

- `checkCartArithmetic(cart)` — each `line_total_paise` equals
  `quantity * unit_price_paise`, and `total_paise` equals their sum.
- `isIntentExpired(intent, now?)`
- `checkCartAgainstIntent(cart, intent, now?)` — reference matches, cart
  total is within `max_paise`, intent isn't expired.
- `checkPaymentAgainstCart(payment, cart)` — reference matches, and
  `final_paise === cart.total_paise`.
- `validateMandateChain(rawIntent, rawCart, rawPayment)` — runs all of the
  above together and returns a single aggregated result.
